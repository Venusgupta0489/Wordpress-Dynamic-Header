<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Insignia
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@600&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css"  crossorigin="anonymous" referrerpolicy="no-referrer" />

<!-- font family -->
	<!-- for heading -->
	<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;600&display=swap" rel="stylesheet">
	<!-- for sub-heading -->
	<link href="https://fonts.googleapis.com/css2?family=Lora:ital@1&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/lightgallery/1.6.14/css/lightgallery.css">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<header id="masthead" class="site-header">
		<div class="container">
			<div class="row">
				<div class="col-lg-2 col-4 d-flex align-items-center">
				   	<?php the_custom_logo() ?>
				</div>
				<div class="col-lg-10 col-8 d-flex justify-content-end align-items-center">
					<nav class="navbar navbar-expand-lg navbar-top p-0">
						<button class="navbar-toggler" type="button" data-bs-toggle="collapse"data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
							<i class="fa fa-bars"></i>
						</button>
						<div class="collapse navbar-collapse" id="navbarSupportedContent">
							<?php
							wp_test_nav_menu(
								array(
									'container'=>'ul',
									'container_class' => 'collapse navbar-collapse',
									'container_id' => 'navbarSupportedContent',
									'menu_class' => 'navbar-nav',
									'li_class' => 'nav-item',
									'li_dropdown' => 'dropdown',
									'a_class' => 'nav-link text-truncate',
									'a_dropdown_class' => 'dropdown-toggle toggle_arrow',
									'a_data_toggle' => 'dropdown',
									'sub_menu_class' => 'dropdown-menu',
									'before_menu_start'=>'<li class="nav-item close-navbar"><a class="nav-link" href="#" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="fa fa-times"></i></a></li>',
									'before_ul_start' => '<div id="overlayear" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"></div>',
									'theme_location' => 'menu-1',
									'menu_id'        => 'primary-menu',
								)
							);
							?>
						</div>
					</nav>
				</div>
			</div>

		</div>
	</header><!-- #masthead -->
